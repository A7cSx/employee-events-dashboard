from fasthtml.common import Div, FT


class CombinedComponent:
    """
    Engine class for building HTML pages composed of multiple BaseComponent
    objects.

    Usage
    -----
    Subclass CombinedComponent and set `children` to an ordered list of
    initialised BaseComponent (or FastHTML FT) instances.

    class MyPage(CombinedComponent):
        children = [Radio(), Dropdown(), LineChart(), DataTable()]
    """

    # Override in each subclass with an ordered list of component instances
    children: list = []

    # CSS class applied to the outer wrapping div
    outer_div_cls: str = "combined-component"

    def call_children(self, entity_id, model) -> list:
        """
        Iterate over `children`, build each one, and return a list of
        FastHTML elements in the same order.

        FastHTML FT objects (e.g. plain H1, P, Hr) are called with no
        arguments; BaseComponent objects receive entity_id and model.
        """
        built = []
        for child in self.children:
            if isinstance(child, FT):
                # Plain FastHTML element — just append directly
                built.append(child)
            else:
                # BaseComponent — call to trigger build_component
                built.append(child(entity_id, model))
        return built

    def outer_div(self, children: list, **div_kwargs) -> "FT":
        """
        Wrap all built children inside a single Div element.
        Additional keyword arguments are forwarded to the Div constructor.
        """
        return Div(
            *children,
            cls=self.outer_div_cls,
            **div_kwargs,
        )

    def __call__(self, entity_id, model):
        children = self.call_children(entity_id, model)
        return self.outer_div(children)
