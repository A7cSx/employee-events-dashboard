from fasthtml.common import Div, H2
from .combined_component import CombinedComponent
from report.base_components import Dropdown, Radio


class FormGroup(CombinedComponent):
    """
    A combined component that groups the entity-type radio buttons and
    the entity dropdown selector together into a single control panel.

    Subclasses set `children` with the appropriate Dropdown and Radio
    instances for their context (employee vs team).
    """

    outer_div_cls = "form-group"
