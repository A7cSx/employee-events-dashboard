from fasthtml.common import Table, Thead, Tbody, Tr, Th, Td, Div, P
from .base_component import BaseComponent


class DataTable(BaseComponent):
    """
    Renders a styled HTML table from a pandas DataFrame returned by
    a SQL query.
    """

    def component_data(self, entity_id, model):
        """Return manager notes for the entity as a DataFrame."""
        return model.notes(entity_id)

    def build_component(self, entity_id, model):
        df = self.component_data(entity_id, model)

        if df.empty:
            return Div(P("No notes on record.", cls="no-data"), cls="table-container")

        header_row = Tr(*[Th(col) for col in df.columns])
        body_rows = [
            Tr(*[Td(str(val)) for val in row]) for _, row in df.iterrows()
        ]

        return Div(
            Table(
                Thead(header_row),
                Tbody(*body_rows),
                cls="data-table",
            ),
            cls="table-container",
        )
