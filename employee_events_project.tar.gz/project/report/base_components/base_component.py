from fasthtml.common import Div


class BaseComponent:
    """
    Abstract base class for all simple HTML components in the dashboard.

    Subclasses must override `build_component` to return a FastHTML element.
    Subclasses that need data must also override `component_data`.

    Calling an initialised subclass instance (i.e. using it like a function)
    will automatically call build_component with the supplied arguments.
    """

    def __call__(self, entity_id, model):
        return self.build_component(entity_id, model)

    # ------------------------------------------------------------------
    # Override these in every subclass
    # ------------------------------------------------------------------

    def build_component(self, entity_id, model):
        """
        Construct and return the FastHTML element for this component.

        Parameters
        ----------
        entity_id : int
            The ID of the selected employee or team.
        model : QueryBase subclass instance
            Provides access to database query methods.
        """
        raise NotImplementedError(
            f"'{type(self).__name__}' must implement build_component()"
        )

    def component_data(self, entity_id, model):
        """
        Execute the required SQL query and return data for this component.
        Only needs to be overridden when the component requires database data.
        """
        raise NotImplementedError(
            f"'{type(self).__name__}' must implement component_data()"
        )
