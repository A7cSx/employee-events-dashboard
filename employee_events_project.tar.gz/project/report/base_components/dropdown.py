from fasthtml.common import Select, Option, Label, Div, Form, Button
from .base_component import BaseComponent


class Dropdown(BaseComponent):
    """
    Renders a labelled <select> dropdown populated from a SQL query.

    Parameters
    ----------
    label       : str   – Label shown above the dropdown.
    route       : str   – The URL prefix used when the form is submitted,
                          e.g. "/employee" → redirects to /employee/{id}
    """

    def __init__(self, label: str = "Select", route: str = "/employee"):
        self.label = label
        self.route = route

    def component_data(self, entity_id, model):
        """Return a DataFrame with columns [id_column, name]."""
        return model.names()

    def build_component(self, entity_id, model):
        df = self.component_data(entity_id, model)
        id_col = model.id_column

        options = [
            Option(
                row["name"],
                value=str(row[id_col]),
                selected=(str(row[id_col]) == str(entity_id)),
            )
            for _, row in df.iterrows()
        ]

        return Div(
            Label(self.label, _for="entity-select"),
            Form(
                Select(*options, id="entity-select", name="entity_id"),
                Button("Go", type="submit"),
                method="get",
                action=self.route,
            ),
            cls="dropdown-container",
        )
