import io
import base64
import matplotlib
matplotlib.use("Agg")           # non-interactive backend — safe for servers
import matplotlib.pyplot as plt
from fasthtml.common import Img, Div
from .base_component import BaseComponent


class MatplotlibViz(BaseComponent):
    """
    Base class for embedding a Matplotlib chart as a base64-encoded PNG
    inside an <img> tag.

    Subclasses must override `visualization` to draw the chart using the
    supplied axes object.
    """

    # Override in subclasses to set figure dimensions
    fig_size = (10, 4)

    def visualization(self, fig, ax, entity_id, model):
        """
        Draw onto `ax`.  Must be overridden by every subclass.
        """
        raise NotImplementedError(
            f"'{type(self).__name__}' must implement visualization()"
        )

    def build_component(self, entity_id, model):
        fig, ax = plt.subplots(figsize=self.fig_size)
        self.visualization(fig, ax, entity_id, model)

        buf = io.BytesIO()
        fig.savefig(buf, format="png", bbox_inches="tight")
        plt.close(fig)
        buf.seek(0)
        img_b64 = base64.b64encode(buf.read()).decode("utf-8")

        return Div(
            Img(src=f"data:image/png;base64,{img_b64}", cls="chart-img"),
            cls="chart-container",
        )
