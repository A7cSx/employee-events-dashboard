from fasthtml.common import Div, Label, Input, Form, Button
from .base_component import BaseComponent


class Radio(BaseComponent):
    """
    Renders a set of radio buttons used to switch between entity types
    (e.g. Employee vs Team).

    Parameters
    ----------
    options : list[tuple[str, str]]
        Each tuple is (label_text, route_value), e.g.
        [("Employee", "/employee"), ("Team", "/team")]
    current_route : str
        The currently active route, used to pre-select the correct button.
    """

    def __init__(
        self,
        options: list = None,
        current_route: str = "/employee",
    ):
        self.options = options or [("Employee", "/employee"), ("Team", "/team")]
        self.current_route = current_route

    def build_component(self, entity_id, model):
        buttons = []
        for label_text, route in self.options:
            buttons.append(
                Label(
                    Input(
                        type="radio",
                        name="view",
                        value=route,
                        checked=(route == self.current_route),
                        onchange="this.form.submit()",
                    ),
                    f" {label_text}",
                )
            )

        return Div(
            Form(
                Div(*buttons, cls="radio-group"),
                method="get",
                action="/",
            ),
            cls="radio-container",
        )
