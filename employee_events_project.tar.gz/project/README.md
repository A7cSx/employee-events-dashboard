# Employee Events Dashboard

A FastHTML web dashboard for monitoring employee performance and recruitment risk, backed by a custom Python package that queries a SQLite database.

## Project Structure

```
├── assets/
│   ├── model.pkl          # Pre-trained recruitment risk ML model
│   └── report.css         # Optional external stylesheet
├── python-package/
│   ├── employee_events/
│   │   ├── __init__.py
│   │   ├── employee.py        # Employee query class
│   │   ├── team.py            # Team query class
│   │   ├── query_base.py      # Shared base query class
│   │   ├── sql_execution.py   # QueryMixin for DB access
│   │   └── employee_events.db # SQLite database
│   ├── requirements.txt
│   └── setup.py
├── report/
│   ├── base_components/       # Individual HTML component classes
│   ├── combined_components/   # Page-level component engines
│   ├── dashboard.py           # FastHTML app & routes
│   └── utils.py               # Path config & model loader
├── tests/
│   └── test_employee_events.py
├── requirements.txt
└── .github/
    └── workflows/
        └── tests.yml          # CI: run pytest on push to main
```

## Setup

### 1. Clone the repository

```bash
git clone <your-fork-url>
cd employee-events-dashboard
```

### 2. Create and activate a virtual environment (Python 3.10+)

```bash
python -m venv env
source env/bin/activate        # Windows: env\Scripts\activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Install the employee_events Python package

```bash
pip install python-package/
```

### 5. Run the dashboard

```bash
cd report
python dashboard.py
```

Then open `http://localhost:5001` in your browser.

## Running Tests

```bash
pytest tests/ -v
```

## Features

- **Employee view** — line chart of cumulative positive/negative events + ML recruitment risk gauge + manager notes
- **Team view** — same visualizations aggregated across all team members
- **Colour-coded risk gauge** — green / amber / red scale for instant risk assessment
- **Dynamic page title** — updates between "Employee Performance" and "Team Performance" based on the active view

## CI/CD

A GitHub Actions workflow (`.github/workflows/tests.yml`) automatically runs `pytest` on every push or pull request to `main`.
