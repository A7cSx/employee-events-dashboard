from setuptools import setup, find_packages

setup(
    name="employee_events",
    version="1.0.0",
    description="Python API for querying the employee_events database",
    packages=find_packages(),
    # Include the SQLite database file inside the installed package
    package_data={"employee_events": ["*.db"]},
    install_requires=[
        "pandas",
    ],
    python_requires=">=3.10",
)
